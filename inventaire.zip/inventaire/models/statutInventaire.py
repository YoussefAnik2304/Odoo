
from odoo import models, fields
class MyStatutInventaire(models.Model):
    _name = 'inventaire.statut_inventaire'
    _description = 'My Statut Inventaire'
    id = fields.Integer('ID')
    statut = fields.Char('Statut')
    

    
    
    



                    