
from odoo import models, fields
class MyUnite(models.Model):
    _name = 'inventaire.unite'
    _description = 'My Unite'
    id = fields.Integer('ID')
    code = fields.Char('Code')
    designation = fields.Char('Designation')   
    

    
    



                    