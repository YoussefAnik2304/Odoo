
from odoo import models, fields
class MyInventairePatrimoine(models.Model):
    _name = 'inventaire.inventaire_patrimoine'
    _description = 'My Inventaire Patrimoine'
    
    inexistant = fields.Boolean('Inexistant')
   
    
    
    



                    