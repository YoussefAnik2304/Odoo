
from odoo import models, fields
class MyPersonne(models.Model):
    _name = 'inventaire.personne'
    _description = 'My Personnel'
    id = fields.Integer('ID')
    matricule = fields.Char('Matricule')
    nom = fields.Char('Nom')
    prenom = fields.Char('Prenom')
    fonction = fields.Char('Fonction')
    tel = fields.Char('Tel')
    fax = fields.Char('Fax')
    email = fields.Char('Email')
   

    
    



                    