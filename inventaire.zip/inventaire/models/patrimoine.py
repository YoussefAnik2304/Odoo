
from odoo import models, fields
class MyPatrimoine(models.Model):
    _name = 'inventaire.patrimoine'
    _description = 'My Patrimoine'
    id = fields.Integer('ID')
    designation = fields.Char('Designation')
    date_acquisition = fields.Date('Date d\'Acquisition')
    valeur_acquisition = fields.Char('Valeur d\'Acquisition')
    date_mise_service = fields.Date('Date de Mise en Service')
    etat_actuel = fields.Char('Etat Actuel')
    n_bc = fields.Char('N° BC')
    n_bl = fields.Char('N° BL')
    n_facture = fields.Char('N° Facture')
    image_actif = fields.Char('Image Actif')
    consigne_securite = fields.Char('consigne de securite')
    degre_importance = fields.Char('degre d\'importance')
    

    



                    