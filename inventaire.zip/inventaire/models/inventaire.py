
from odoo import models, fields
class MyInventaire(models.Model):
    _name = 'inventaire.inventory'
    _description = 'My Inventaire'
    id = fields.Integer('ID')
    code = fields.Char('Code')
    libelle = fields.Char('Libelle')
    responsable = fields.Char('Responsable')
    date_lancement = fields.Date('Date de l\'lancement')
    date_Encours = fields.Date('Date en cours')
    date_saisi = fields.Date('Date de saisi')
    date_validite = fields.Date('Date de validite')
    date_cloture = fields.Date('Date de cloture')
    

    
   
    



                    