
from odoo import models, fields
class MyEtat(models.Model):
    _name = 'inventaire.etat'
    _description = 'My Etat'
    id = fields.Integer('ID')
    libelle = fields.Char('Libelle')
    

    
    
    



                    