# -*- coding: utf-8 -*-
{
    'name': 'inventaire',
    'version': '1.0',
    'category': 'Custom',
    'summary': 'A description of your module',
    'description': """Detailed description of your module""",
    'author': 'Your Name',
    'website': 'https://www.example.com',
    'depends': ['base'],
    'data': [
        # 'views/view_file.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}
