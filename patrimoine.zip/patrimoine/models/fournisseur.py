from odoo import models, fields, api
class Fournisseur(models.Model):
    _name = 'patrimoine.fournisseur'
    _description = 'les fournisseurs'
    id = fields.Integer('ID')
    code = fields.Char('Code')
    denomination=fields.Char('Denomination')
    adresse=fields.Char('Adresse')
    tele = fields.Char('Telephone')
    fax = fields.Char('Fax') 
    email= fields.Char('Email')  
    nom_fournisseur = fields.Char('Nom')
    prenom_fournisseur = fields.Char('Prenom') 
    GSM1 = fields.Char('GSM1') 
    GSM2 = fields.Char('GSM2') 
    patrimoine_actif_ids=One2many('patrimoine.partimoine_actif','fournisseur_id',string='patrimoine actifs')
