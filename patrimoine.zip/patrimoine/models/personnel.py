from odoo import models, fields, api
class Personnel(models.Model):
    _name = 'patrimoine.personnel'
    _description = 'les personnels'
    matricule = fields.Char('Matricule')
    nom = fields.Char('Nom')
    prenom = fields.Char('Prenom')
    fonction = fields.Char('Fonction')
    tele = fields.Char('Telephone')
    fax = fields.Char('Fax') 
    email= fields.Char('Email')    
    patrimoine_actif_ids=One2many('patrimoine.partimoine_actif','personnel_id',string='patrimoine actifs')
    patrimoine_geographique_id=Many2one('patrimoine.patrimoine_geographique',string'patrimoine geographique')
    responsable_ids=One2many('patrimoine.personnel','responsable_id',string='responsables')
    categorie_personnel_id=Many2one('patrimoine.categorie_personnel',string='categorie personnel')
    
