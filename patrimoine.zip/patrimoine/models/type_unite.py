from odoo import models, fields, api
class TypeUnite(models.Model):
    _name = 'patrimoine.type_unite'
    _description = 'Le type de mon unité'
    libelle = fields.Char('Libelle')
    unite_ids=One2many('patrimoine.unite','type_unite_id',string='unites')
    
