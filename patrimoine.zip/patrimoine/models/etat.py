from odoo import models, fields
class Etat(models.Model):
    _name = 'patrimoine.etat'
    _description = 'L\'etat de mon patrimoine'
    libelle = fields.Char('Libelle')
    etat_patrim_actif_ids=One2many('patrimoine.etat_patrim_actif','etat_id',string='etats patrimoine actifs') 
    
