from odoo import models, fields
class CategoriePatrimoineActif(models.Model):
    _name = 'patrimoine.categorie_patrimoine_actif'
    _description = 'La catégorie de mon patrimoine actif'
    libelle = fields.Char('Libelle')
    sous_famille_id=Many2one('patrimoine.sous_famille',string='sous famille')
    patrimoine_actif_ids=One2many('patrimoine.patrimoine_actif','patrimoine_actif_id',string='patrimoines actif')
