from odoo import models, fields, api
class Unite(models.Model):
    _name = 'patrimoine.unite'
    _description = 'L\'unité de  de mon patrimoine'
    code = fields.Char('Code')
    designation=fields.Char('Designation')
    patrimoine_actif_ids=One2many('patrimoine.partimoine_actif','unite_id',string='patrimoine actifs')
    patrimoine_geographique_id=Many2one('patrimoine.patrimoine_geographique',string'patrimoine geographique')
    type_unite_id=Many2one('patrimoine.type_unite',string'type unite')
