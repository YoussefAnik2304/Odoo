from odoo import models, fields, api
class SousFamille(models.Model):
    _name = 'patrimoine.sous_famille'
    _description = 'Le sous famille'
    libelle = fields.Char('Libelle')
    famille_id=Many2one('patrimoine.famille',string='famille')
    categorie_patrimoine_actif_ids=One2many('patrimoine.categorie_partimoine_actif','sous_famille_id',string='categories patrimoines actifs')
    
