from odoo import models, fields, api
class PatrimoineGeographique(models.Model):
    _name = 'patrimoine.patrimoine_geographique'
    _description = 'My PatrimoineGeographique'
    code = fields.Char('Code')
    designation = fields.Char('Designation')
    croques = fields.Char('croques')
    fiche_immeuble = fields.Char('Fiche Immeuble')
    fiche_etage = fields.Char('Fiche Etage')
    fiche_local = fields.Char('Fiche Local')    
    patrimoine_actif_ids=One2many('patrimoine.partimoine_actif','patrimoine_geographique_id',string='patrimoine actifs')
    unite_ids=One2many('patrimoine.unite','patrimoine_geographique_id',string='unite')
    personnel_ids=One2many('patrimoine.personnel','patrimoine_geographique_id',string='personnels')
    responsable_id=Many2one('patrimoine.personnel',string'responsable')
    type_patrimoine_id=Many2one('patrimoine.type_patrimoine',string'type patrimoine')
