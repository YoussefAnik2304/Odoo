from odoo import models, fields, api
class Famille(models.Model):
    _name = 'patrimoine.famille'
    _description = 'famille'
    libelle = fields.Char('Libelle')
    sous_familles_ids=One2many('patrimoine.sous_famille','famille_id',string='sous  familles')
    
