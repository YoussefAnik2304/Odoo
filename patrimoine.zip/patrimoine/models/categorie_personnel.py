from odoo import models, fields
class CategoriePersonnel(models.Model):
    _name = 'patrimoine.categorie_personnel'
    _description = 'La categorie personnel'
    libelle = fields.Char('Libelle')
    personnel_ids=One2many('patrimoine.personnel','categorie_personnel_id',string='personnel')
    
