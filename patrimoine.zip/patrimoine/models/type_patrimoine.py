from odoo import models, fields, api
class TypePatrimoine(models.Model):
    _name = 'patrimoine.type_patrimoine'
    _description = 'Le type de mon patrimoine'
    libelle = fields.Char('Libelle')
    patrimoine_geographique_ids=One2many('patrimoine.partimoine_geographique','type_patrimoine_id',string='patrimoines geographiques')
    
    
