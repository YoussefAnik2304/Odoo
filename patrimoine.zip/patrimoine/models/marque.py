from odoo import models, fields, api
class Marque(models.Model):
    _name = 'patrimoine.marque'
    _description = 'La marque de mon patrimoine'
    libelle = fields.Char('Libelle')
    patrimoine_actif_ids=One2many('patrimoine.partimoine_actif','marque_id',string='patrimoine actifs')
