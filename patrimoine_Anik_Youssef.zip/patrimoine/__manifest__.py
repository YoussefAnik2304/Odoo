{
    'name':'my_patrimoine',
    'summary': 'Gestion de patrimoine',
    'depends': ['base'],
    'data': ['views/patrimoine_patrimoineGeographique_view.xml',
             'views/patrimoine_personnel_view.xml',
             'views/patrimoine_fournisseur_view.xml',
             'views/patrimoine_patrimoineActif_view.xml',
             'views/patrimoine_famille_view.xml',
             'views/patrimoine_sousfamille_view.xml',
             'views/patrimoine_marque_view.xml',
             'views/patrimoine_categoriePatrimoineActif_view.xml',
             'views/patrimoine_typePatrimoine_view.xml',
             'views/patrimoine_categoriePersonnel_view.xml',
             'views/patrimoine_etat_view.xml',
             'views/patrimoine_etatPatrimoineActif_view.xml',
             'views/patrimoine_typeUnite_view.xml',
             'views/patrimoine_unite_view.xml']  
}
