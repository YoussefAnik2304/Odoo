from odoo import models, fields, api
class TypePatrimoine(models.Model):
    _name = 'patrimoine.type_patrimoine'
    _description = 'Le type de mon patrimoine'
    id = fields.Integer('ID')
    libelle = fields.Char('Libelle')
    