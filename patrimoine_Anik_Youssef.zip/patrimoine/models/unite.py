from odoo import models, fields, api
class Unite(models.Model):
    _name = 'patrimoine.unite'
    _description = 'L\'unité de  de mon patrimoine'
    id = fields.Integer('ID')
    code = fields.Char('Code')
    designation=fields.Char('Designation')
    