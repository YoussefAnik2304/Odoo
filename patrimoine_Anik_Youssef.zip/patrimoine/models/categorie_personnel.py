from odoo import models, fields
class CategoriePersonnel(models.Model):
    _name = 'patrimoine.categorie_personnel'
    _description = 'La categorie personnel'
    id = fields.Integer('ID')
    libelle = fields.Char('Libelle')
    