from odoo import models, fields, api
class Famille(models.Model):
    _name = 'patrimoine.famille'
    _description = 'famille'
    id = fields.Integer('ID')
    libelle = fields.Char('Libelle')
    