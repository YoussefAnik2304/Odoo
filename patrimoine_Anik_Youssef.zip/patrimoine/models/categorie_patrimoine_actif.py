from odoo import models, fields
class CategoriePatrimoineActif(models.Model):
    _name = 'patrimoine.categorie_patrimoine_actif'
    _description = 'La catégorie de mon patrimoine actif'
    id = fields.Integer('ID')
    libelle = fields.Char('Libelle')
    