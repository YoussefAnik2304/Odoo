from odoo import models, fields, api
class PatrimoineGeographique(models.Model):
    _name = 'patrimoine.patrimoine_geographique'
    _description = 'My PatrimoineGeographique'
    id = fields.Integer('ID')
    code = fields.Char('Code')
    designation = fields.Char('Designation')
    croques = fields.Char('croques')
    fiche_immeuble = fields.Char('Fiche Immeuble')
    fiche_etage = fields.Char('Fiche Etage')
    fiche_local = fields.Char('Fiche Local')    