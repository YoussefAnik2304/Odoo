from odoo import models, fields, api
class Marque(models.Model):
    _name = 'patrimoine.marque'
    _description = 'La marque de mon patrimoine'
    id = fields.Integer('ID')
    libelle = fields.Char('Libelle')
    