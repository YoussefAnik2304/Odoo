from odoo import models, fields, api
class SousFamille(models.Model):
    _name = 'patrimoine.sous_famille'
    _description = 'Le sous famille'
    id = fields.Integer('ID')
    libelle = fields.Char('Libelle')
    