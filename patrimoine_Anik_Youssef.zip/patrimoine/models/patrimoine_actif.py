from odoo import models, fields, api
class PatrimoineActif(models.Model):
    _name = 'patrimoine.patrimoine_actif'
    _description = 'My Patrimoine Actif'
    id = fields.Integer('ID')
    code = fields.Char('Code')
    designation = fields.Char('Designation')
    valeur_acquisition = fields.Char('Valeur d\'acquisition')
    date_acquisition = fields.Date('Date d\'acquisition')
    date_mise_service = fields.Date('Date de mise service')   
    etat_actuelle = fields.Char('L\'etat actuelle')   
    N_BC=fields.Char('Numero BC')
    N_BL=fields.Char('Numero BL')
    N_facture=fields.Char('Numero de facture')
    image_actif=fields.Char('Image actif')
    consigne_securite=fields.Char('Consigne de securite ')
    degre_importance=fields.Char('Degre d\'importance')
    