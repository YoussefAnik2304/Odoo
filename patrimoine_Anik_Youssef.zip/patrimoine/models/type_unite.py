from odoo import models, fields, api
class TypeUnite(models.Model):
    _name = 'patrimoine.type_unite'
    _description = 'Le type de mon unité'
    id = fields.Integer('ID')
    libelle = fields.Char('Libelle')
    