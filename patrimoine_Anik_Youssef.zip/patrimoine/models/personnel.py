from odoo import models, fields, api
class Personnel(models.Model):
    _name = 'patrimoine.personnel'
    _description = 'les personnels'
    id = fields.Integer('ID')
    matricule = fields.Char('Matricule')
    nom = fields.Char('Nom')
    prenom = fields.Char('Prenom')
    fonction = fields.Char('Fonction')
    tele = fields.Char('Telephone')
    fax = fields.Char('Fax') 
    email= fields.Char('Email')    