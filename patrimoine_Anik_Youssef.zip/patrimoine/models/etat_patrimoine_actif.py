from odoo import models, fields
class EtatPatrimoineActif(models.Model):
    _name = 'patrimoine.etat_patrimoine_actif'
    _description = 'L\'etat de mon patrimoine actif'
    date_etat = fields.Date('Date_Etat')
    
    