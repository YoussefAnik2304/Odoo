from odoo import models, fields
class Etat(models.Model):
    _name = 'patrimoine.etat'
    _description = 'L\'etat de mon patrimoine'
    id = fields.Integer('ID')
    libelle = fields.Char('Libelle')
    